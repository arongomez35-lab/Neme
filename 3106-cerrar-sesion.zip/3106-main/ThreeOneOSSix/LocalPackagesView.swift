import SwiftUI
import UIKit

/// A safe in-app file shelf for the four supplied .3105 packages.
/// Apply copies the original package into the app's Documents/AppliedPackages
/// folder. Restore removes that managed copy; it does not run package code.
struct LocalPackagesView: View {
    let onLogout: () -> Void
    @State private var expandedID: String?
    @State private var statusMessage: String?
    @State private var statusIsError = false
    @State private var refreshToken = UUID()

    private struct PackageItem: Identifiable {
        let id: String
        let title: String
        let fileName: String
        let group: String
        let symbol: String
    }

    private let antennaItems = [
        PackageItem(id: "aim-antenna", title: "R1 AIM pecho - antena", fileName: "R1 AIM pecho - antena.3105", group: "ANTENA", symbol: "scope"),
        PackageItem(id: "aim-vip", title: "R1 X R5 Aimbot Pecho VIP", fileName: "R1 X R5 Aimbot Pecho VIP.3105", group: "ANTENA", symbol: "target")
    ]
    private let holoItems = [
        PackageItem(id: "holo-pj", title: "R1 holo pj", fileName: "R1 holo pj.3105", group: "HOLO", symbol: "sparkles"),
        PackageItem(id: "holo-celeste", title: "R1 X R5 Holograma Celeste", fileName: "R1 X R5 Holograma Celeste.3105", group: "HOLO", symbol: "wand.and.stars")
    ]

    var body: some View {
        ZStack {
            Color(red: 0.035, green: 0.045, blue: 0.085).ignoresSafeArea()
            ScrollView {
                VStack(alignment: .leading, spacing: 22) {
                    topBar
                    header
                        packageSection(title: "ANTENA", subtitle: "Archivos de antena", items: antennaItems, accent: Color(red: 0.22, green: 0.72, blue: 1.0))
                        packageSection(title: "HOLO", subtitle: "Archivos de holograma", items: holoItems, accent: Color(red: 0.60, green: 0.42, blue: 1.0))
                        if let statusMessage {
                            Label(statusMessage, systemImage: statusIsError ? "exclamationmark.triangle.fill" : "checkmark.circle.fill")
                                .font(.footnote.weight(.medium))
                                .foregroundStyle(statusIsError ? .orange : .green)
                                .padding(12)
                                .frame(maxWidth: .infinity, alignment: .leading)
                                .background(.white.opacity(0.07), in: RoundedRectangle(cornerRadius: 12))
                        }
                        Text("APLICAR guarda una copia del archivo dentro de la app. RESTAURAR elimina esa copia. Los paquetes se conservan intactos y no se ejecuta código ni se modifican juegos o el sistema.")
                            .font(.caption)
                            .foregroundStyle(.white.opacity(0.55))
                            .padding(.top, 2)
                }
                .padding(.horizontal, 18)
                .padding(.top, 8)
                .padding(.bottom, 28)
            }
        }
        .preferredColorScheme(.dark)
    }

    private var topBar: some View {
        HStack {
            Text("MIS ARCHIVOS")
                .font(.system(size: 19, weight: .bold, design: .rounded))
                .foregroundStyle(.white)
            Spacer()
            Button(action: onLogout) {
                Text("CERRAR SESIÓN")
                    .font(.system(size: 13, weight: .semibold, design: .rounded))
                    .foregroundStyle(.white)
                    .padding(.horizontal, 16)
                    .padding(.vertical, 11)
                    .background(Color.white.opacity(0.08), in: Capsule())
                    .overlay(Capsule().stroke(Color.cyan.opacity(0.28), lineWidth: 1))
            }
            .buttonStyle(.plain)
        }
        .padding(.top, 10)
        .padding(.bottom, 8)
    }

    private var header: some View {
        VStack(alignment: .leading, spacing: 7) {
            Text("CENTRO DE ARCHIVOS")
                .font(.system(size: 12, weight: .bold, design: .rounded))
                .tracking(2.2)
                .foregroundStyle(Color.cyan)
            Text("Tus paquetes .3105")
                .font(.system(size: 27, weight: .bold, design: .rounded))
                .foregroundStyle(.white)
            Text("Selecciona un archivo para ver sus acciones.")
                .font(.subheadline)
                .foregroundStyle(.white.opacity(0.6))
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(.vertical, 8)
    }

    private func packageSection(title: String, subtitle: String, items: [PackageItem], accent: Color) -> some View {
        VStack(alignment: .leading, spacing: 11) {
            HStack(spacing: 10) {
                RoundedRectangle(cornerRadius: 2).fill(accent).frame(width: 4, height: 27)
                VStack(alignment: .leading, spacing: 2) {
                    Text(title).font(.headline.weight(.heavy)).tracking(1.4).foregroundStyle(.white)
                    Text(subtitle).font(.caption).foregroundStyle(.white.opacity(0.5))
                }
                Spacer()
                Text("\(items.count) ARCHIVOS")
                    .font(.system(size: 9, weight: .bold, design: .rounded))
                    .tracking(0.8)
                    .foregroundStyle(accent)
                    .padding(.horizontal, 9).padding(.vertical, 6)
                    .background(accent.opacity(0.13), in: Capsule())
            }
            ForEach(items) { item in
                packageCard(item, accent: accent)
            }
        }
    }

    private func packageCard(_ item: PackageItem, accent: Color) -> some View {
        let isExpanded = expandedID == item.id
        let isApplied = appliedURL(for: item) != nil
        return VStack(spacing: 0) {
            Button {
                withAnimation(.easeInOut(duration: 0.2)) {
                    expandedID = isExpanded ? nil : item.id
                }
            } label: {
                HStack(spacing: 12) {
                    Image(systemName: item.symbol)
                        .font(.system(size: 18, weight: .semibold))
                        .foregroundStyle(accent)
                        .frame(width: 42, height: 42)
                        .background(accent.opacity(0.13), in: RoundedRectangle(cornerRadius: 12))
                    VStack(alignment: .leading, spacing: 4) {
                        Text(item.title).font(.subheadline.weight(.semibold)).foregroundStyle(.white).multilineTextAlignment(.leading)
                        Text(isApplied ? "ARCHIVO APLICADO · COPIA LOCAL" : "ARCHIVO ORIGINAL · .3105")
                            .font(.system(size: 9, weight: .bold, design: .rounded))
                            .tracking(0.6)
                            .foregroundStyle(isApplied ? .green : .white.opacity(0.42))
                    }
                    Spacer(minLength: 4)
                    Image(systemName: isExpanded ? "chevron.up" : "chevron.down")
                        .font(.system(size: 12, weight: .bold)).foregroundStyle(.white.opacity(0.65))
                }
                .padding(13)
                .contentShape(Rectangle())
            }
            .buttonStyle(.plain)
            if isExpanded {
                Divider().overlay(.white.opacity(0.08))
                HStack(spacing: 10) {
                    actionButton(title: "APLICAR", symbol: "arrow.down.to.line", tint: accent) { apply(item) }
                    actionButton(title: "RESTAURAR", symbol: "arrow.uturn.backward", tint: Color(red: 1, green: 0.56, blue: 0.38)) { restore(item) }
                }
                .padding(12)
            }
        }
        .background(Color.white.opacity(0.055), in: RoundedRectangle(cornerRadius: 16))
        .overlay(RoundedRectangle(cornerRadius: 16).stroke(.white.opacity(isExpanded ? 0.18 : 0.08), lineWidth: 1))
        .id(refreshToken)
    }

    private func actionButton(title: String, symbol: String, tint: Color, action: @escaping () -> Void) -> some View {
        Button(action: action) {
            Label(title, systemImage: symbol)
                .font(.system(size: 11, weight: .heavy, design: .rounded))
                .tracking(0.5)
                .foregroundStyle(.white)
                .frame(maxWidth: .infinity)
                .padding(.vertical, 13)
                .background(tint.opacity(0.22), in: RoundedRectangle(cornerRadius: 10))
                .overlay(RoundedRectangle(cornerRadius: 10).stroke(tint.opacity(0.55), lineWidth: 1))
        }
        .buttonStyle(.plain)
    }

    private func appliedURL(for item: PackageItem) -> URL? {
        let directory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
            .appendingPathComponent("AppliedPackages", isDirectory: true)
        let url = directory.appendingPathComponent(item.fileName)
        return FileManager.default.fileExists(atPath: url.path) ? url : nil
    }

    private func apply(_ item: PackageItem) {
        guard let source = Bundle.main.url(forResource: URL(fileURLWithPath: item.fileName).deletingPathExtension().lastPathComponent, withExtension: "3105", subdirectory: "PackageFiles") else {
            report("No se encontró \(item.fileName) dentro de la app.", isError: true)
            return
        }
        do {
            let directory = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0]
                .appendingPathComponent("AppliedPackages", isDirectory: true)
            try FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true)
            let destination = directory.appendingPathComponent(item.fileName)
            if FileManager.default.fileExists(atPath: destination.path) {
                try FileManager.default.removeItem(at: destination)
            }
            try FileManager.default.copyItem(at: source, to: destination)
            refreshToken = UUID()
            report("\(item.title): copia guardada en la app.")
        } catch {
            report("No se pudo guardar el archivo: \(error.localizedDescription)", isError: true)
        }
    }

    private func restore(_ item: PackageItem) {
        guard let destination = appliedURL(for: item) else {
            report("\(item.title): no hay una copia aplicada para restaurar.", isError: true)
            return
        }
        do {
            try FileManager.default.removeItem(at: destination)
            refreshToken = UUID()
            report("\(item.title): copia local restaurada/eliminada.")
        } catch {
            report("No se pudo restaurar el archivo: \(error.localizedDescription)", isError: true)
        }
    }

    private func report(_ message: String, isError: Bool = false) {
        statusMessage = message
        statusIsError = isError
    }
}
