import SwiftUI

/// The authenticated landing screen is the local .3105 package shelf.
/// The previous Features navigation is intentionally not presented here.
struct ContentView: View {
    let onLogout: () -> Void

    var body: some View {
        LocalPackagesView(onLogout: onLogout)
    }
}
