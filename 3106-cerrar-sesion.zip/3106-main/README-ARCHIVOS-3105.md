# Integración de archivos .3105

Se añadió un acceso **MIS ARCHIVOS** en la esquina inferior derecha de la app. La pantalla organiza los cuatro paquetes originales en dos grupos:

- **ANTENA**: `R1 AIM pecho - antena.3105` y `R1 X R5 Aimbot Pecho VIP.3105`.
- **HOLO**: `R1 holo pj.3105` y `R1 X R5 Holograma Celeste.3105`.

Al expandir cada tarjeta aparecen **APLICAR** y **RESTAURAR**. En esta integración, APLICAR copia el archivo original al directorio privado `Documents/AppliedPackages`; RESTAURAR elimina esa copia gestionada. Los originales dentro del bundle no se modifican.

**Límite funcional:** el formato `.3105` es un paquete de modificación y esta integración no interpreta ni ejecuta su payload. Por tanto, los botones gestionan los archivos reales dentro de la app, pero no aplican cambios a juegos, al sistema ni ejecutan exploits.

Abrir `ThreeOneOSSix.xcodeproj` en Xcode y compilar el scheme principal para probar la pantalla.
